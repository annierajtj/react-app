import React from 'react';
import { useRoutes } from 'react-router-dom';
import { CssBaseline, ThemeProvider } from '@mui/material';
import Router from './routes/Router';
import { theme } from './theme';


const App = () => {

  const routing = useRoutes(Router);
  return (
    <ThemeProvider theme={theme}>
     <CssBaseline />
        {routing}
      </ThemeProvider>
  );
};

export default App;

