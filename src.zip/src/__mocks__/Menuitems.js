const Menuitems = [
  {
    navlabel: true,
    subheader: 'HOME',
    icon: 'mdi mdi-dots-horizontal',
    href: 'Dashboard',
  },
  {
    title: 'Dashboard',
    icon: 'message-square',
    href: '/dashboard',
  },
  {
    navlabel: true,
    subheader: 'APPS',
    icon: 'mdi mdi-dots-horizontal',
    href: 'Apps',
  },
  {
    title: 'Chat',
    icon: 'message-square',
    href: '/chats',
  },
  {
    title: 'Notes',
    icon: 'clipboard',
    href: '/notes',
  },
  {
    title: 'Customers',
    icon: 'users',
    href: '/customers',
    collapse: true,
    children: [
      {
        title: 'Lists',
        icon: 'list',
        href: '/customers/lists',
      },
      {
        title: 'Edit',
        icon: 'edit',
        href: '/customers/edit',
      },
    ],
  },
  {
    navlabel: true,
    subheader: 'PAGES',
    icon: 'mdi mdi-dots-horizontal',
    href: 'Pages',
  },
  {
    title: 'Reset Password',
    icon: 'refresh-ccw',
    href: '/reset-password',
  },
];

export default Menuitems;
