export const users= [
    {
        id:1,
        name: 'Annie Raj',
        email: 'annie@srswebsolutions.com',
        password:'Srsweb123#'

    },
    {
        id:2,
        name: 'Admin',
        email: 'admin@srswebsolutions.com',
        password:'Admin@Srs123#'
    }

];
 