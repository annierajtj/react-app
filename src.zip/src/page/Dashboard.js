import React from 'react';
import { Grid } from '@mui/material';
import {WelcomeCard, Purchases, TotalEarnings} from './../components/dashboard';
import PageContainer from './../components/container/PageContainer';

const Dashboard = () => (
  
  <PageContainer title="Dashboard" description="this is Dashboard page">
    <Grid container spacing={0}>
    <Grid item xs={12} sm={4} lg={5}>
        <WelcomeCard />
      </Grid>
      <Grid item xs={12} sm={4} lg={3}>
        <Purchases />
      </Grid>
      <Grid item xs={12} sm={4} lg={4}>
        <TotalEarnings />
      </Grid>
    </Grid>
  </PageContainer>
);
export default Dashboard;
