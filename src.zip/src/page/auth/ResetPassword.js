import React from 'react'
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Grid, Box, Button, Typography} from '@mui/material';
import { Link } from 'react-router-dom';
import TextField from '../../components/container/CustomTextField';
import PageContainer from '../../components/container/PageContainer';

const ResetPassword = () => {
  const formik = useFormik({
      initialValues: {
        email: '',
      },
      validationSchema: Yup.object({
        email: Yup
          .string()
          .email('Invalid email')
          .min(2, 'Too Short!')
          .max(30, 'Too Long!')
          .required('Email is required')
      }),
      onSubmit: (values,helpers) => {
        console.log(values);
        helpers.setFieldError('submit', 'Zalter authentication not enabled');
        helpers.setSubmitting(false);
      }
    });

    return(

  <PageContainer title="Reset Password" description="this is Reset Password page">
    <Grid container spacing={0} sx={{ height: '100vh', justifyContent: 'center' }}>
      <Grid
        item
        xs={12}
        sm={12}
        lg={6}
        sx={{
          background:'#ffffff',
        }}
      >
        <Box
          sx={{
            position: 'relative',
          }}
        >
          <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            sx={{
              position: {
                xs: 'relative',
                lg: 'absolute',
              },
              height: { xs: 'auto', lg: '100vh' },
              right: { xs: 'auto', lg: '-50px' },
              margin: '0 auto',
            }}
          >
            <img
              src={process.env.PUBLIC_URL + '/asset/images/login-bg.svg'}  
              alt="bg"
              style={{
                width: '100%',
                maxWidth: '812px',
              }}
            />
          </Box>
          <Box
            sx={{
              p: 4,
              position: 'absolute',
              top: '0',
            }}
          >
            <img
              src={process.env.PUBLIC_URL + '/asset/images/mConsent-logo.png'}                                   
              alt="mConsent Logo"
              style={{
                width: '100%',
                maxWidth: '150px',
              }}
             />   
          </Box>
        </Box>
      </Grid>
      <Grid item xs={12} sm={8} lg={6} display="flex" alignItems="center">
        <Grid container spacing={0} display="flex" justifyContent="center">
          <Grid item xs={12} lg={9} xl={6}>
            <Box
              sx={{
                p: 4,
              }}
            >
              <Typography variant="h2" fontWeight="700">
                Forgot your password?
              </Typography>

              <Typography
                color="textSecondary"
                variant="h5"
                fontWeight="400"
                sx={{
                  mt: 2,
                }}
              >
                Please enter the email address associated with your account and We will email you a
                link to reset your password.
              </Typography>

              <form onSubmit={formik.handleSubmit}>
             <Box
                sx={{
                  mt: 4,
                }}
              >
            <TextField
              error={Boolean(formik.touched.email && formik.errors.email)}
              fullWidth
              helperText={formik.touched.email && formik.errors.email}
              label="Email Address"
              margin="normal"
              name="email"
              size="small"
              autoComplete="off"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="email"
              value={formik.values.email}
              variant="outlined"
              htmlFor="reset-email"
            />
               
                <Button
                  color="secondary"
                  variant="contained"
                  size="large"
                  fullWidth
                  disabled={formik.isSubmitting}
                  type="submit"
                  sx={{
                    pt: '10px',
                    pb: '10px',
                    mt: 4,
                  }}
                >
                  Reset Password
                </Button>
                <Button
                  color="secondary"
                  size="large"
                  fullWidth
                  component={Link}
                  to="/"
                  sx={{
                    pt: '10px',
                    pb: '10px',
                    mt: 2,
                  }}
                >
                  Back to Login
                </Button>
              </Box>
              </form>
            </Box>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  </PageContainer>
);
};

export default ResetPassword;
