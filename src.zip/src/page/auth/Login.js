import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Grid, Box, Button, Typography, FormGroup, FormControlLabel, Checkbox} from '@mui/material';
import PageContainer from '../../components/container/PageContainer';
import TextField from '../../components/container/CustomTextField';
import Swal from 'sweetalert2'
import withReactContent from 'sweetalert2-react-content'

const swal = withReactContent(Swal)

const Login = ({ users}) => {
  
  const navigate = useNavigate();

  const formik = useFormik({
      initialValues: {
        email: '',
        password: ''
      },
      validationSchema: Yup.object({
        email: Yup
          .string()
          .email('Invalid email')
          .min(2, 'Too Short!')
          .max(30, 'Too Long!')
          .required('Email is required'),
        password: Yup
          .string()
          .min(2, 'Too Short!')
          .max(30, 'Too Long!')
          .required('Password is required')
      }),
      onSubmit: (values) => {
        users.map(({email,password}) => {
          if(email == values.email && password == values.password){
            navigate('/dashboard');
          }else{
            swal.fire({
              title: 'Error!',
              text: 'Username/Password Incorrect',
              icon: 'error',
              confirmButtonColor: '#e67e5f',
              })
          }
      });
      }
    });
    return(
    <PageContainer title="Login" description="this is Login page">
       <Grid container spacing={0} sx={{ height: '100vh', justifyContent: 'center' }}>
      <Grid
        item
        xs={12}
        sm={12}
        lg={6}
        sx={{
          background:'#ffffff',
        }}
      >
        <Box
          sx={{
            position: 'relative',
          }}
        >
     
     <Box
            display="flex"
            alignItems="center"
            justifyContent="center"
            sx={{
              position: {
                xs: 'relative',
                lg: 'absolute',
              },
              height: { xs: 'auto', lg: '100vh' },
              right: { xs: 'auto', lg: '-50px' },
              margin: '0 auto',
            }}
          >
            <img
              src={process.env.PUBLIC_URL + '/asset/images/login-bg.svg'}                                   
              alt="bg"
              style={{
                width: '100%',
                maxWidth: '812px',
              }}
            />                                                                      
          </Box>
          <Box
            sx={{
              p: 4,
              position: 'absolute',
              top: '0',
            }}
          >
            <img
              src={process.env.PUBLIC_URL + '/asset/images/mConsent-logo.png'}                                   
              alt="mConsent Logo"
              style={{
                width: '100%',
                maxWidth: '150px',
              }}
             />   
          </Box>
        </Box>
      </Grid>
      <Grid item xs={12} sm={8} lg={6} display="flex" alignItems="center">
        <Grid container spacing={0} display="flex" justifyContent="center">
          <Grid item xs={12} lg={9} xl={6}>
            <Box
              sx={{
                p: 4,
              }}
            >
              <Typography fontWeight="700" variant="h2">
                Welcome to  mConsent
              </Typography>
              <Box display="flex" alignItems="center">
                <Typography
                  color="textSecondary"
                  variant="h6"
                  fontWeight="500"
                  sx={{
                    mr: 1,
                  }}
                >
                  New to mConsent?
                </Typography>
                <Typography
                  component={Link}
                  to="/register"
                  fontWeight="500"
                  sx={{
                    display: 'block',
                    textDecoration: 'none',
                    color: 'primary.main',
                  }}
                >
                  Create an account
                </Typography>
              </Box>
              <form onSubmit={formik.handleSubmit}>
             <Box
                sx={{
                  mt: 4,
                }}
              >
            <TextField
              error={Boolean(formik.touched.email && formik.errors.email)}
              fullWidth
              helperText={formik.touched.email && formik.errors.email}
              label="Username"
              margin="normal"
              name="email"
              size="small"
              autoComplete="off"
              onChange={formik.handleChange}
              type="email"
              value={formik.values.email}
              variant="outlined"
            />
            <TextField
              error={Boolean(formik.touched.password && formik.errors.password)}
              fullWidth
              helperText={formik.touched.password && formik.errors.password}
              label="Password"
              margin="normal"
              name="password"
              size="small"
              autoComplete="off"
              onChange={formik.handleChange}
              type="password"
              value={formik.values.password}
              variant="outlined"
            />
          
                <Box
                  sx={{
                    display: {
                      xs: 'block',
                      sm: 'flex',
                      lg: 'flex',
                    },
                    alignItems: 'center',
                  }}
                >
                  <FormGroup>
                    <FormControlLabel
                      control={<Checkbox defaultChecked />}
                      label="Remember me"
                      sx={{
                        mb: 2,
                      }}
                    />
                  </FormGroup>
                  <Box
                    sx={{
                      ml: 'auto',
                    }}
                  >
                    <Typography
                      component={Link}
                      to="/reset-password"
                      fontWeight="500"
                      sx={{
                        display: 'block',
                        textDecoration: 'none',
                        mb: '16px',
                        color: 'primary.main',
                      }}
                    >
                      Forgot Password ?
                    </Typography>
                  </Box>
                </Box>

                <Button
                  color="secondary"
                  variant="contained"
                  size="large"
                  fullWidth
                  type="submit"
                  sx={{
                    pt: '10px',
                    pb: '10px',
                  }}
                >
                  Sign In
                </Button>
              </  Box>
              </form>
            </Box>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
    </PageContainer>
    );
  };
  export default Login;
  