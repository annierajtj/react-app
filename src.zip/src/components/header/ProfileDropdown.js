import React from 'react';
import { Box, MenuItem, Typography, Avatar, Button, Divider } from '@mui/material';
import FeatherIcon from 'feather-icons-react';

const ProfileDropdown = () => (
  <Box>
    <Box
      sx={{
        pb: 3,
        mt: 3,
      }}
    >
      <Box display="flex" alignItems="center">
        <Avatar
          src={process.env.PUBLIC_URL + '/asset/images/undraw_female.svg'}          
          alt='user profile'
          sx={{
            width: '90px',
            height: '90px',
          }}
        />
        <Box
          sx={{
            ml: 2,
          }}
        >
          <Typography
            variant="h4"
            sx={{
              lineHeight: '1.235',
            }}
          >
            Annie Raj
          </Typography>
          <Typography color="textSecondary" variant="h6" fontWeight="400">
            Administrator
          </Typography>
          <Box display="flex" alignItems="center">
            <Typography
              color="textSecondary"
              display="flex"
              alignItems="center"
              sx={{
                color: (theme) => theme.palette.grey.A200,
                mr: 1,
              }}
            >
              <FeatherIcon icon="mail" width="18" />
            </Typography>
            <Typography color="textSecondary" variant="h6">
             annie@srswebsolutions.com
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  </Box>
);

export default ProfileDropdown;
