import React from 'react';
import { Link } from 'react-router-dom';


const LogoIcon = () => {
  return (
    <Link underline="none" to="/">
     <img
              src={process.env.PUBLIC_URL + '/asset/images/login-bg.svg'}                                   
              alt="bg"
              style={{
                width: '100%',
                maxWidth: '812px',
              }}
            />    
    </Link>
  );
};

export default LogoIcon;
