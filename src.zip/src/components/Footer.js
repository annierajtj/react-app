import React from 'react';
import { Box, Typography } from '@mui/material';

const Footer = () => (
  <Box sx={{ p: 3, textAlign: 'center' }}>
    <Typography>© {(new Date().getFullYear())} All rights reserved </Typography>
  </Box>
);

export default Footer;
