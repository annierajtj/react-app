import React from 'react';
import { Navigate } from 'react-router-dom';
import { users } from '../__mocks__/users';


//Layout
const DefaultLayout = React.lazy(() => import('../layout/DefaultLayout'))
const BlankLayout =  React.lazy(() => import('../layout/BlankLayout'));

//Auth
const Error = React.lazy(() => import('../page/auth/Error'));
const Login = React.lazy(() => import('../page/auth/Login'));
const Register = React.lazy(() => import('../page/auth/Register'));
const ResetPassword = React.lazy(() => import('../page/auth/ResetPassword'));

//Pages
const Dashboard = React.lazy(() => import('../page/Dashboard'));

const Router = [
    {
        path: 'dashboard',
        element: <DefaultLayout />,
        children: [
            { path: 'dashboard', element: <Navigate to="/dashboard" /> },
            { path: '/dashboard', exact: true, element: <Dashboard /> },
    ],
    },
    {
    path: '/',
    element: <BlankLayout />,
    children: [
        { path: '404', element: <Error /> },
        { path: '/', element: <Login  users={users} /> },
        { path: 'register', element: <Register /> },
        { path: 'reset-password', element: <ResetPassword /> },
        { path: '*', element: <Navigate to="/404" /> },
    ],
    },
];
export default Router