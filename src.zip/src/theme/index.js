import { createTheme } from '@mui/material';
import typography from './Typography';
import components from './Override';
import shadows from './Shadows';

const SidebarWidth = 265;
const TopbarHeight = 70;

const theme = createTheme({
    components,
    palette: {
        background: {
          default: '#fafbfb',
          dark: '#ffffff',
          paper: '#ffffff',
        },
        text: {
          primary:'rgba(0, 0, 0, 0.87)',
          secondary:'#777e89',
          danger: '#fc4b6c',
        },
        primary: {
            main: '#03c9d7',
            light: '#e5fafb',
            dark: '#05b2bd',
            contrastText: '#ffffff',
          },
          secondary: {
            main: '#fb9678',
            light: '#fcf1ed',
            dark: '#e67e5f',
            contrastText: '#ffffff',
          },
          success: {
          main: '#00c292',
          light: '#ebfaf2',
          dark: '#00964b',
          contrastText: '#ffffff',
        },
        danger: {
          main: '#e46a76',
          light: '#fdf3f5',
        },
        info: {
          main: '#0bb2fb',
          light: '#a7e3f4',
        },
        error: {
          main: '#e46a76',
          light: '#fdf3f5',
          dark: '#e45a68',
        },
        warning: {
          main: '#fec90f',
          light: '#fff4e5',
          dark: '#dcb014',
          contrastText: '#ffffff',
        },
        grey: {
          A100: '#ecf0f2',
          A200: '#99abb4',
          A400: '#767e89',
          A700: '#e6f4ff',
        },
      },
      mixins: {
        toolbar: {
          color: '#949db2',
          '@media(min-width:1280px)': {
            minHeight: TopbarHeight,
            padding: '0 30px',
          },
          '@media(max-width:1280px)': {
            minHeight: '64px',
          },
        },
      },
      direction: 'ltr',
    shape: {
      borderRadius: 5
    },
    shadows,
    typography
  });

  
export { TopbarHeight, SidebarWidth, theme };

  